# Dashboard

## Links
- [[Memory]]
- [[Taskforce]]
- [[Resell Business]]

## Current direction
Mission Control dashboard should stay clean, practical, and action-oriented. Avoid flashy graph experiments unless Lewis asks.
