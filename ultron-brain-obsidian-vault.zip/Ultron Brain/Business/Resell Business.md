# Resell Business

## Core links
- [[Lewis]]
- [[Memory]]
- [[Inventory]]
- [[eBay Workflow]]

## Platforms
- eBay
- Depop
- Vinted

## Current operating idea
Ultron is the inventory system. Dashboard shows stock, sales, active listings, and next actions.
