# Inventory

## Links
- [[Resell Business]]
- [[eBay Workflow]]

## Source files
- `inventory/us-stock.json`
- `inventory/uk-stock.json`
- `inventory/uk-ebay-listing-map.json`
