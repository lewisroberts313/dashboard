# eBay Workflow

## Links
- [[Resell Business]]
- [[Inventory]]

## Rules
- Draft/review first unless Lewis explicitly says publish.
- Space listing batches by 10 minutes.
- If duplicate auction-style block: 30-minute cooldown, retry, then fallback.
- After paid sale/postage QR: extract QR and send handler-ready context.
