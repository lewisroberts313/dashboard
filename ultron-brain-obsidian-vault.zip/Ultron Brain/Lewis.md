# USER.md - About Lewis

- **Name:** Lewis
- **What to call them:** Lewis
- **Timezone:** America/New_York (EST/EDT)
- **Notes:** Wants a second brain to reduce stress. No off-limits topics. Prefers direct, efficient help.

## Context

- Uses Discord as primary messaging channel (DMs with bot)
- Discord username: lewis.313
- Discord ID: 1124343949423804456
- Values action over discussion — just get it done

## Life

- Student-athlete (soccer) at a college in Florida
- From the UK originally
- On a soccer scholarship
- Main stress: finances — paying for college
- Goal: find a financially stable way to pay for college

## Side Business

- Sources clothes from China via ACBuy agent
- Platforms: Depop, Vinted, eBay
- Wants to make this more autonomous/hands-off
- Ditched Google Sheets — Ultron is the inventory system now
- "summary" command = full stock + stats + sold breakdown
- Biggest pain point: inventory tracking / spreadsheet updates
- Has someone in UK handling shipping
