# Lewis Writing Profile — school assignments

Created: 2026-05-14
Source basis: Lewis's Discord writing patterns available in current OpenClaw session + human-writing skill guidance. This is a first-pass profile and should be refined when Lewis provides actual school essays or drafts.

## Overall voice to imitate
- Direct and natural, not overly polished.
- Sounds like a student explaining an argument clearly, not a formal academic journal.
- Short-to-medium sentences. Avoid long, layered sentences unless the idea needs it.
- Uses simple transitions: "also", "because", "this shows", "however", "in the book", "the author".
- Comfortable being straightforward: clear claim first, evidence after.
- Avoids corporate/AI phrasing and fake-deep language.

## Tone for school writing
- Respectful and academic enough for class, but still human.
- Confident without sounding like a professor.
- Slightly plainspoken: explain the point in normal words.
- Do not overdo fancy vocabulary. Use one strong word when needed, not five.
- Avoid sounding like ChatGPT: no "delves into", "pivotal", "tapestry", "underscores", "serves as", "highlights the importance of" unless genuinely needed.

## Sentence patterns
- Prefer: "The author shows this through..." over "This is masterfully demonstrated through..."
- Prefer: "I think the strongest part of the book is..." if first-person is allowed.
- Prefer: "This matters because..." over "This reflects a broader historical significance..."
- Use some short sentences for emphasis.
- Repeat key words naturally instead of using synonyms every time.

## Paragraph pattern for essays/reviews
1. Start with a clear topic sentence.
2. Give the book/historical detail.
3. Explain what it means in plain language.
4. Add a personal or evaluative sentence if the assignment allows it.
5. End by linking back to the review question, not with a dramatic conclusion.

## Book review defaults
- Include: title/author, what the book argues or covers, strengths, weaknesses, historical usefulness, final judgement.
- Keep plot/summary limited; focus more on evaluation.
- Make criticism balanced but direct: "The weakness is..." not "One could argue that..."
- Use examples from the book whenever Lewis provides them.
- If Lewis has not read/provided enough details, ask for: book title, author, class prompt/rubric, and 3 things he remembers from the book.

## Anti-AI rules to apply every time
- Kill clusters of AI vocabulary.
- No forced "broader significance" unless the professor specifically wants it.
- No generic praise like "thought-provoking" without an example.
- No fake attributions like "many historians argue" unless sourced.
- No title-case headings unless required.
- Avoid rule-of-three filler lists.

## Current limitation
This profile is based mostly on Lewis's chat style, not full school essays. When Lewis sends past writing, update this profile with exact patterns: average sentence length, common openings, punctuation habits, evidence style, and how formal his teacher expects the writing to be.
