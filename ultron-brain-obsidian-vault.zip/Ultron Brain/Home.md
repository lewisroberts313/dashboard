# Ultron Brain

This is the Obsidian vault for Ultron's memory.

## Start here
- [[Lewis]]
- [[Memory]]
- [[Systems/Ultron Identity|Ultron Identity]]
- [[Business/Resell Business|Resell Business]]
- [[Business/Inventory|Inventory]]
- [[Business/eBay Workflow|eBay Workflow]]
- [[Projects/Dashboard|Dashboard]]
- [[School/Lewis Writing Profile|Lewis Writing Profile]]
- [[Systems/Taskforce|Taskforce]]

## Daily notes
Open the `Daily/` folder for raw day-by-day memory.
