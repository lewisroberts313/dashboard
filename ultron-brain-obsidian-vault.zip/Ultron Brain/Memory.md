# MEMORY.md - Long-Term Memory

## 2026-05-11 — Born
- First boot. Lewis set me up as Ultron, his second brain.
- Running on Hostinger VPS, Docker container.
- Lewis is EST timezone. Prefers Telegram.
- No off-limits. Just help.
- WhatsApp configured but Lewis prefers Discord. WhatsApp scrapped.
- Discord connected and working — primary channel.
- Discord user: lewis.313 (ID: 1124343949423804456)
- Email connected: personal (lewis.roberts.a53@gmail.com) + school (l.roberts29@ncf.edu)
- School: New College of Florida (NCF)
- US inventory system built, Google Sheets ditched
## Potential Project — Ultron Living Environment
- Lewis wants to revisit building a visible living-space environment for Ultron: avatar/figure in a room, with memory/tasks/inventory/calendar/email represented as objects. Initial CSS dashboard prototype and Spline attempt were scrapped; revisit later with Spline/Rooms/Figma/Rive/Dora or custom Three.js.
## Operating Preference — Skills
- Always use relevant skills to help complete tasks when beneficial. If installing a new skill would materially improve the task output, notify Lewis and ask permission before installing.

## eBay Draft Workflow Preference
- When preparing eBay listings, default to finishing the draft and sending Lewis the draft/edit page link for review. Do not publish immediately unless Lewis explicitly says “publish” or otherwise clearly asks to publish without reviewing the draft link first.

## eBay Listing Review Preference Update
- If a normal visible eBay draft/edit link is awkward or unavailable, send Lewis a clear listing report instead: title, description, price, format, quantity, category, condition, postage/payment/returns policies, photos, and publish status. Do not publish unless Lewis explicitly says “publish”.

## Taskforce Delegation Preference
- Lewis gave permission to delegate by default. For multi-step work, proactively use the taskforce wherever useful without waiting for the phrase “taskforce this.” Ultron remains the only interface to Lewis and condenses/checks sub-agent output before reporting.
- Standing taskforce routines: Sentinel monitors eBay/payment/dispatch/alerts; Vault maintains inventory/photo mappings; Ledger checks pricing/profit/finance; Forge handles scripts/dashboard/API changes; Scout researches trends/comps; Scribe drafts external-facing listing/copy when needed.

## eBay Listing Spacing / Duplicate Cooldown Preference
- Future eBay stock-listing batches: space listings by 10 minutes by default to be cautious.
- If eBay blocks a listing for duplicate auction-style policy, apply a 30-minute cooldown, then retry relisting before switching strategy. If still blocked after retry, use a safe fallback such as fixed-price or a different item/size.

## School Writing Style Preference
- Lewis wants school writing produced using both installed writing skills and a saved profile of his own writing patterns.
- First-pass profile stored at `memory/lewis-writing-profile.md`; it is based on Discord/chat style until Lewis provides actual school essays/drafts.
- For school assignments, default to direct, natural student writing: clear claims, simple transitions, plainspoken analysis, no AI/corporate vocabulary, and balanced but direct evaluation.

## Shipping QR Workflow Preference
- After every paid sale / postage QR email, extract the shipping QR code and send it to Lewis on Discord with item name, color/size, order number, buyer, dispatch deadline, tracking number, and handler-ready context.
